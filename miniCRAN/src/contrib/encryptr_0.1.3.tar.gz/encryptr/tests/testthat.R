library(testthat)
library(encryptr)

test_check("encryptr")
