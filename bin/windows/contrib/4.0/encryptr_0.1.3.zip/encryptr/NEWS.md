# encryptr 0.1.3

* File encryption include, `encrypt_file()` and `decrypt_file()`. 


# encryptr 0.1.2

* CRAN requirements fulfilled.

# encryptr 0.1.1

* `genkeys()` bug fixes and rework. #1 #2
* `encrypt()` errors if .csv immediately, not after encryption done.


# encryptr 0.1.0

* `encrypt()`, `decrypt()` and `genkeys()` basic functions, together with helpers.
