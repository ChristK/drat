## ---- eval=FALSE--------------------------------------------------------------
#  library(sigma)
#  data <- system.file("examples/ediaspora.gexf.xml", package = "sigma")
#  sigma(data)

