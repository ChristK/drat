## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----setup, include=FALSE-----------------------------------------------------
library(submitr)

## ----eval=FALSE---------------------------------------------------------------
#  learnr::run_tutorial("minimal", package = "submitr")

## ----echo=FALSE, fig.cap="Snapshot of the minimal tutorial at start-up", out.width="80%"----
knitr::include_graphics("images/minimal-first-page.png")

## ----eval=FALSE---------------------------------------------------------------
#  file.copy(
#    system.file("tutorials/Minimal/minimal.Rmd", package = "submitr"),
#    "./minimal.Rmd")

## ----eval = FALSE-------------------------------------------------------------
#    in_google_sheets(
#      "1w3fEld2rZlR_6FuzvkA-viOLBA5JdqD3xHl-LuLX3-Y",
#      "statprep.annie@gmail.com",
#      vfun)

