# `{submitr}` : A package for logging `{learnr}` tutorial events

See the vignette for the package, available [here](dtkaplan.github.io/submitr)
